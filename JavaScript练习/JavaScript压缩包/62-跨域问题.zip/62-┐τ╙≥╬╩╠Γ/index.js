
fn({name: 123})