
// console.log(aa + bb)
// add(2, 10)

// let a = 10
// import { add } from './03.js'
// let aaa = '';
// if (a == 10) {
//   aaa = import('./02.js')

// }
// let aa = './02.js'
// import(aa).then((res) => {
//   console.log(res.num)
//   // let { num, bb, add } = res;
//   // console.log(num, bb, add)
// })
// import * as aa from './02.js'
// console.log(aa)

import obj from './02.js'
console.log(obj)

// setTimeout(() => { console.log(num) }, 2000)


// import './02.js'

// if (true) {

//   function aa() { }
// } else {
//   function aa() { }
// }
