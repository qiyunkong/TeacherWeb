
// let result = 0
// for (let i = 2; i < 10; i++) {
//   result += i;
// }
// export { result }
let num = 10
let bb = 20
function add(min, max) {
  // return (num + bb)
  let result = 0
  for (let i = min; i < max; i++) {
    result += i;
  }
  console.log(result)
}

// console.log(num, bb, add)
// export {

// }

export default 10


// export let num = 10

// setTimeout(() => {
//   num = 30
// }, 2000)



