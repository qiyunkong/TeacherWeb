function text() {
  console.log(1)
}