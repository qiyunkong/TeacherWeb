/**
 * type:
 *   DIV  JS  H5 CSS 3
 * **/
var flyData = [
  {
    type: "Css3",
    author: '无为',
    title: '我感觉你在为难我',
    desc: '这个案例很屌',
    time: '2019-09-26',
    src: '3D Drag'
  }, {
    type: "Js",
    author: '虎子',
    title: '测试一下',
    desc: '这个案例很屌',
    time: '2019-09-27',
    src: '3D Drag'
  }
]
