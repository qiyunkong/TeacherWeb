import { num } from './01.js'
console.log(num)