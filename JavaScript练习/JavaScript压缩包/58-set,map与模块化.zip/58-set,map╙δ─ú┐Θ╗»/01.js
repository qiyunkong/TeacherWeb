// export let num = 10
let num = 10